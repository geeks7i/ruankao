package com.ch.spring_boot_mystarters;
public class MyService {
	private String mid;
	private String mname;
	private String mclass;

	public String say() {
		String str;
		str=getMid()+getMname()+getMclass();
		return "我的信息：" + str;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getMid() {
		return mid;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public void setMclass(String mclass) {
		this.mclass = mclass;
	}

	public String getMname() {
		return mname;
	}

	public String getMclass() {
		return mclass;
	}

}
