package com.ch.spring_boot_mystarters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration//启用配置类，即加载到Spring容器
//快速注册属性配置类MyProperties，该类用属性文件提供参数
@EnableConfigurationProperties(MyProperties.class)
//类加载器（类路径）中是否存在对应的类，若存在，启用该配置类
@ConditionalOnClass(MyService.class)
//应用环境中属性是否存在my.enabled属性，如果不存在，根据matchIfMissing的执行决定是否启用该配置类
@ConditionalOnProperty(prefix = "my", value = "enabled", matchIfMissing = true)
public class MyAutoConfiguration {
	@Autowired
	private MyProperties myProperties;
	@Bean
	//当容器中不存在MyService的Bean时，自动配置这个Bean
	@ConditionalOnMissingBean(MyService.class)
	public MyService myService() {
		MyService myService = new MyService();
		myService.setMid(myProperties.getMid());
		myService.setMname(myProperties.getMname());
		myService.setMclass(myProperties.getMclass());
		return myService;
	}
}
