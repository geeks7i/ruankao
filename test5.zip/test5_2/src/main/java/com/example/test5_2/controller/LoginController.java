package com.example.test5_2.controller;

import com.example.test5_2.mode.Book;
import com.example.test5_2.mode.Goods;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class LoginController {

    @RequestMapping("/login")
    public String login(@ModelAttribute("goodsInfo") @Validated Goods goods, BindingResult rs){
        //@ModelAttribute("goodsInfo")与th:object="${goodsInfo}"相对应

        goods.setRight(true);
        if(goods.getGname()!=null&&(!goods.getGname().equals("zhangtao"))){
            goods.setRight(false);
        }
        if (goods.getGpassword()!=null&&(!goods.getGpassword().equals("202110098252"))) {
            goods.setRight(false);
        }
        if(goods.getGname()!=null&&goods.getGpassword()!=null&&goods.getGname().equals("zhangtao")&&goods.getGpassword().equals("202110098252")){
            goods.setRight(true);
            return "redirect:/books";
        }
        if(rs.hasErrors()){//验证失败
            if(rs.hasFieldErrors("gname")||rs.hasFieldErrors("gpassword")){
                goods.setRight(true);
                return "login";
            }
            return "login";
        }
        if(goods.getGname().equals("zhangtao")&&goods.getGpassword().equals("202110098252")){
            goods.setRight(true);
        }
        //验证成功，可以到books界面
        return "redirect:/books";
    }

    @RequestMapping("/books")
    public String books(Model model) {
        Book teacherGeng = new Book(
                "9787302464259",
                55.3,
                "Java 2",
                "清华大学出版社",
                "耿祥义",
                "073423-02.jpg"
        );
        List<Book> chenHeng = new ArrayList<Book>();
        Book b1 = new Book(
                "9787302529118",
                20.5,
                "Java Web",
                "清华大学出版社",
                "陈恒",
                "082526-01.jpg"
        );
        chenHeng.add(b1);
        Book b2 = new Book(
                "9787302502968",
                50.2,
                "Java EE",
                "清华大学出版社",
                "陈恒",
                "079720-01.jpg");
        chenHeng.add(b2);
        model.addAttribute("aBook", teacherGeng);
        model.addAttribute("books", chenHeng);
        //根据Tymeleaf模板，默认将返回src/main/resources/templates/books.html
        return "books";
    }
}
