package com.example.test5_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test53ApplicationTests {

    @Test
    void contextLoads() {
    }

}
