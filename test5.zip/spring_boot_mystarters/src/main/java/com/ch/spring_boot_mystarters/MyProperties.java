package com.ch.spring_boot_mystarters;
import org.springframework.boot.context.properties.ConfigurationProperties;
//在application.properties中通过my.msg=设置属性
//通过该注解为下列bean的属性注入属性文件中的值，类似@Value的效果
@ConfigurationProperties(prefix="my")
public class MyProperties {
	private String mid ="学号：202110098252 " ;
	private String mname="姓名：张涛 ";
	private String mclass="班级：软件工程2班 A";


	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getMid() {
		return mid;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public void setMclass(String mclass) {
		this.mclass = mclass;
	}

	public String getMname() {
		return mname;
	}

	public String getMclass() {
		return mclass;
	}
}
