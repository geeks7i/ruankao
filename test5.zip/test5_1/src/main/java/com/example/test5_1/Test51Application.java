package com.example.test5_1;

import com.ch.spring_boot_mystarters.MyService;
import jakarta.annotation.Resource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@SpringBootApplication
public class Test51Application {
	@Resource
	MyService myService;

	public static void main(String[] args) {
		SpringApplication.run(Test51Application.class, args);
	}
	@RequestMapping("/testStarters")
	public String index(){
		return myService.say();
	}

}

