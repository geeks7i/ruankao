package com.example.test5_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test52Application {

    public static void main(String[] args) {
        SpringApplication.run(Test52Application.class, args);
    }

}
