package com.ch.spring_boot_mystarters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMystartersApplicationTests {

	@Test
	void contextLoads() {
	}

}
