package com.example.test5_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test51ApplicationTests {

	@Test
	void contextLoads() {
	}

}
