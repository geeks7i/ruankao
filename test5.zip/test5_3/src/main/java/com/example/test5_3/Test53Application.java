package com.example.test5_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test53Application {

    public static void main(String[] args) {
        SpringApplication.run(Test53Application.class, args);
    }

}
