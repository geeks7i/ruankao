package com.example.test5_2.mode;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

public class Goods {
    @NotBlank(message="用户名必须输入")
    @Length(min=6, max=20, message="用户名名长度在6到20之间")
    private String gname;
    @NotBlank(message="用户密码必须输入")
    @Length(min=6,max=20,message="用户密码在6到20之间")
    private String gpassword;
    public String getGname() {
        return gname;
    }

    public void setGpassword(String gpassword) {
        this.gpassword = gpassword;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }
    public String getGpassword() {
        return gpassword;
    }

    @AssertTrue(message = "用户名或密码错误")
    private boolean right;

    public void setRight(boolean right) {
        this.right = right;
    }

    public boolean getRight(){
        return right;
    }

}
